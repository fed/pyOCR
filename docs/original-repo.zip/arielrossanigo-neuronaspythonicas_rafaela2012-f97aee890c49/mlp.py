# -*- coding: utf-8 -*-
import scipy as sp
import numpy
import functions
import pylab
import pickle

mul = sp.multiply


class Layer(object):
    def __init__(self, n_inputs, n_outputs, activation_function,
                    derived_function):
        self.BIAS = sp.random.random(size=(n_outputs, 1)) / n_inputs
        self.W = sp.random.random(size=(n_outputs, n_inputs)) / n_inputs
        self.activation_function = activation_function
        self.derived_function = derived_function
        self.vectorize_functions()
        self.reset_deltas()

    def vectorize_functions(self):
        self.af = sp.vectorize(self.activation_function, otypes=[numpy.float])
        self.df = sp.vectorize(self.derived_function, otypes=[numpy.float])

    def activate(self, X):
        self.last_inputs = X
        s = (self.W * X) + self.BIAS
        self.last_outputs = self.af(s)
        self.last_derivatives = self.df(self.last_outputs)
        return self.last_outputs

    def reset_deltas(self):
        self.delta_w = sp.zeros(self.W.shape)
        self.delta_BIAS = sp.zeros(self.BIAS.shape)


class MLP(object):
    def __init__(self, *layers):
        self.layers = list(layers)

    def activate(self, inputs):
        i = inputs
        for l in self.layers:
            i = l.activate(i)
        return i

    def reset_deltas(self):
        for l in self.layers:
            l.reset_deltas()

    def dump(self, filename):
        for l in self.layers:
            l.af = None
            l.df = None

        f = open(filename, 'wb')
        try:
            pickle.dump(self, f)
        finally:
            f.close()

    def vectorize_functions(self):
        for layer in self.layers:
            layer.vectorize_functions()

    @classmethod
    def load(cls, filename):
        f = open(filename, 'r')
        try:
            res = pickle.load(f)
            res.vectorize_functions()
        finally:
            f.close()
        return res


class BackPropagationTrainer(object):
    def __init__(self, estimation_subset, **kw_args):
        self.learn_rate = kw_args.get('learn_rate', 0.5)
        self.adapt_rate = kw_args.get('adapt_rate', True)
        self.estimation_errors = []
        self.errors_es = []
        self.estimation_subset = estimation_subset

    def train(self, network, training_set):
        ##reset deltas from previous train
        network.reset_deltas()

        for x, t in training_set:
            #forward feed
            y = network.activate(x)

            e = t - y
            ##back propagation
            for layer in network.layers[::-1]:
                ro = mul(layer.last_derivatives, e)
                layer.delta_w += mul(ro, layer.last_inputs.T)
                layer.delta_BIAS += ro
                e = layer.W.T * ro

        #weight updates
        for l in network.layers:
            lts = len(training_set)
            l.W = l.W + self.learn_rate * ((l.delta_w / lts))
            l.BIAS = l.BIAS + self.learn_rate * ((l.delta_BIAS / lts))

    def adapt_learn_rate(self, previous_error, current_error):
        if (previous_error > current_error):
            self.learn_rate *= 1.03
        else:
            self.learn_rate *= 0.5

    def loop_train(self, network, **kw_args):
        max_iter = kw_args.get('max_iter', 100)
        max_error = kw_args.get('max_error', 1e-20)
        error = functions.error_avg(network, self.estimation_subset)
        self.estimation_errors.append(error)

        self.iterations = 0
        while (self.iterations < max_iter and error > max_error):
            self.train(network, self.estimation_subset)
            error = functions.error_avg(network, self.estimation_subset)
            self.estimation_errors.append(error)
            if self.adapt_rate:
                self.adapt_learn_rate(*self.estimation_errors[-2:])
            self.iterations += 1

            if self.iterations % 100 == 0:
                print 'Iteration:', self.iterations, \
                'Error estimacion: %16.11f' % error, \
                'Rate: %12.11f' % self.learn_rate

    def dump(self, filename):
        f = open(filename, 'w')
        try:
            pickle.dump(self, f)
        finally:
            f.close()

    @classmethod
    def load(cls, filename):
        f = open(filename, 'r')
        try:
            res = pickle.load(f)
        finally:
            f.close()
        return res

    def show_error_evolution(self, filename=None, from_epoch=0):
        l = self.estimation_errors[from_epoch:]
        t = numpy.arange(from_epoch, from_epoch + len(l))
        s = numpy.array(l)
        pylab.plot(t, s, label='Estimacion')

        pylab.legend()
        pylab.xlabel('Epocas')
        pylab.ylabel(u'Error cuadrático medio')
        pylab.title(u'Curva de aprendizaje')
        pylab.grid(True)
        if filename:
            pylab.savefig(filename)
        pylab.show()


if __name__ == '__main__':
    pass
